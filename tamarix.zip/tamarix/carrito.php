<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: login.php");
    exit;
}

$id_cliente = intval($_SESSION['id']);

// Eliminar un producto del carrito
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    $conn->query("DELETE FROM carrito WHERE id_producto = $id AND id_cliente = $id_cliente");
}

// Confirmar compra
if (isset($_POST['confirmar'])) {
    $conn->begin_transaction();
    try {
        // Calcular total
        $res = $conn->query("SELECT SUM(subtotal) AS total FROM carrito WHERE id_cliente = $id_cliente");
        $total = $res->fetch_assoc()['total'] ?? 0;

        if ($total > 0) {
            // Insertar en ventas
            $stmt = $conn->prepare("INSERT INTO ventas (id_cliente, total) VALUES (?, ?)");
            $stmt->bind_param("id", $id_cliente, $total);
            $stmt->execute();
            $id_venta = $stmt->insert_id;

            // Insertar en detalle_venta y actualizar stock
            $sql_carrito = "SELECT id_producto, cantidad, precio_unitario FROM carrito WHERE id_cliente = ?";
            $stmt_c = $conn->prepare($sql_carrito);
            $stmt_c->bind_param("i", $id_cliente);
            $stmt_c->execute();
            $result = $stmt_c->get_result();

            while ($row = $result->fetch_assoc()) {
                $id_prod = $row['id_producto'];
                $cant = $row['cantidad'];
                $precio = $row['precio_unitario'];
                $subtotal = $precio * $cant;

                $conn->query("INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario, subtotal)
                              VALUES ($id_venta, $id_prod, $cant, $precio, $subtotal)");

                $conn->query("UPDATE productos SET cantidad = cantidad - $cant WHERE id_producto = $id_prod");
            }

            // Vaciar carrito
            $conn->query("DELETE FROM carrito WHERE id_cliente = $id_cliente");
            $conn->commit();
            $mensaje = "✅ Compra registrada correctamente. ID de venta: $id_venta";
        } else {
            $mensaje = "⚠️ Tu carrito está vacío.";
        }
    } catch (Exception $e) {
        $conn->rollback();
        $mensaje = "❌ Error al registrar la compra: " . $e->getMessage();
    }
}

// Obtener productos del carrito
$sql = "SELECT c.id_producto, p.nombre, p.descripcion, p.categoria, c.precio_unitario, c.cantidad, c.subtotal
        FROM carrito c
        JOIN productos p ON c.id_producto = p.id_producto
        WHERE c.id_cliente = $id_cliente";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Carrito</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background-color: #ffe4e1; }
        h1 { color: #444; }
        .mensaje { background-color: #e7ffe7; padding: 10px; border-radius: 8px; margin: 10px 0; }
        .boton { background-color: pink; padding: 8px 15px; border-radius: 5px; border: none; cursor: pointer; }
        .boton:hover { background-color: #ffb6c1; }
    </style>
</head>
<body>
    <h1>🛒 Mi Carrito</h1>
    <a href="catalogo_cliente.php">⬅️ Volver al catálogo</a>
    <?php if (isset($mensaje)) echo "<div class='mensaje'>{$mensaje}</div>"; ?>

    <table>
        <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
            <th>Acción</th>
        </tr>
        <?php
        $total = 0;
        while ($row = $result->fetch_assoc()):
            $total += $row['subtotal'];
        ?>
        <tr>
            <td><?= htmlspecialchars($row['nombre']) ?></td>
            <td><?= $row['cantidad'] ?></td>
            <td>$<?= number_format($row['precio_unitario'], 2) ?></td>
            <td>$<?= number_format($row['subtotal'], 2) ?></td>
            <td><a href="?eliminar=<?= $row['id_producto'] ?>">🗑️ Eliminar</a></td>
        </tr>
        <?php endwhile; ?>
        <tr>
            <th colspan="3">TOTAL</th>
            <th colspan="2">$<?= number_format($total, 2) ?></th>
        </tr>
    </table>

    <form method="post">
        <button type="submit" name="confirmar" class="boton">✅ Confirmar compra</button>
    </form>
</body>
</html>
