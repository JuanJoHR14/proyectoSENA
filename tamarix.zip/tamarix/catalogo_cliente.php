<?php
session_start();
include("conexion.php");

// Verificar que haya sesión y que sea cliente
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: login.php");
    exit;
}

$id_cliente = intval($_SESSION['id']);

// Si se presiona "Agregar al carrito"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $id_producto = intval($_POST['id_producto']);
    $cantidad = max(1, intval($_POST['cantidad']));

    // Obtener información del producto
    $sql = "SELECT id_producto, nombre, precio_unitario, cantidad FROM productos WHERE id_producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_producto);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($producto = $result->fetch_assoc()) {
        if ($producto['cantidad'] >= $cantidad) {
            $precio_unitario = $producto['precio_unitario'];
            $subtotal = $cantidad * $precio_unitario;

            // Verificar si ya existe en el carrito
            $sql_check = "SELECT cantidad FROM carrito WHERE id_cliente = ? AND id_producto = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("ii", $id_cliente, $id_producto);
            $stmt_check->execute();
            $res_check = $stmt_check->get_result();

            if ($res_check->num_rows > 0) {
                // Si ya existe, solo actualizar cantidad y subtotal
                $row_check = $res_check->fetch_assoc();
                $nueva_cantidad = $row_check['cantidad'] + $cantidad;
                $nuevo_subtotal = $nueva_cantidad * $precio_unitario;

                $sql_update = "UPDATE carrito 
                               SET cantidad = ?, subtotal = ? 
                               WHERE id_cliente = ? AND id_producto = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("ddii", $nueva_cantidad, $nuevo_subtotal, $id_cliente, $id_producto);
                $stmt_update->execute();
                $mensaje = "🛒 Se actualizó la cantidad del producto en el carrito.";
            } else {
                // Si no existe, insertarlo normalmente
                $sql_insert = "INSERT INTO carrito (id_cliente, id_producto, cantidad, precio_unitario, subtotal)
                               VALUES (?, ?, ?, ?, ?)";
                $stmt_insert = $conn->prepare($sql_insert);
                $stmt_insert->bind_param("iiidd", $id_cliente, $id_producto, $cantidad, $precio_unitario, $subtotal);
                $stmt_insert->execute();
                $mensaje = "✅ Producto agregado al carrito.";
            }
        } else {
            $mensaje = "⚠️ No hay suficiente stock disponible.";
        }
    } else {
        $mensaje = "❌ Producto no encontrado.";
    }
}


// Consultar productos
//se realiza una relacion entre bds
$sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.precio_unitario, p.categoria, p.cantidad, p.imagen, p.fecha_publicacion AS proveedor
        FROM productos p
        LEFT JOIN proveedores pro 
        ON p.id_pro = pro.id_pro";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo de Productos</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background-color: #ffe4e1; }
        h1 { color: #444; }
        .mensaje { background-color: #e7ffe7; padding: 10px; border-radius: 8px; margin: 10px 0; }
        .carrito-btn { float: right; background-color: pink; padding: 10px; border-radius: 5px; text-decoration: none; }
        .carrito-btn:hover { background-color: #ffb6c1; }
    </style>
</head>
<body>
    <h1>Catálogo de Productos</h1>
    <a href="carrito.php" class="carrito-btn">🛒 Ver carrito</a>
    <?php if (isset($mensaje)) echo "<div class='mensaje'>{$mensaje}</div>"; ?>

    <table>
        <tr>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Proveedor</th>
            <th>Cantidad</th>
            <th>Acción</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['nombre']) ?></td>
            <td><?= htmlspecialchars($row['categoria']) ?></td>
            <td>$<?= number_format($row['precio_unitario'], 2) ?></td>
            <td><?= $row['cantidad'] ?></td>
            <td><?= htmlspecialchars($row['proveedor']) ?></td>
            <td>
                <form method="post" style="margin:0;">
                    <input type="hidden" name="id_producto" value="<?= $row['id_producto'] ?>">
                    <input type="number" name="cantidad" value="1" min="1" max="<?= $row['cantidad'] ?>" style="width: 60px;">
            </td>
            <td>
                    <button type="submit" name="add_to_cart">Agregar</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
