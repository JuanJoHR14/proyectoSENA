<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="user.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <form action="" method="POST">
        <table>
            <tr>
                <td><label>NOMBRE Y APELLIDO</label></td>
            </tr>
            <tr>
                <td><input type="text"  name="text_nombre" placeholder="Ingresar su nombre" required></td>
            </tr>
            <tr>
                <td><label>NOMBRE USUARIO</label></td>
            </tr>
            <tr>
                <td><input type="text"  name="text_username" placeholder="Nombre de usuario" required></td>
            </tr>
            <tr>
                <td><label>IDENTIFICACION</label></td>
            </tr>
            <tr>
                <td><input type="number" name="text_identificacion" placeholder="Ingresar N° de identificación" required ></td>
            </tr>
            <tr>
                <td><label>TELEFONO</label></td>
            </tr>
            <tr>
                <td><input type="number" name="num_telefono" placeholder="Ingresar N° telefonico" required ></td>
            </tr>
            <tr>
                <td><label>CORREO ELECTRONICO</label></td>
            </tr>
            <tr>
                <td><input type="text" name="text_correo" placeholder="ingresar correo electronico" required></td>
            </tr>
            <tr>
                <td><label>FECHA DE NACIMIENTO</label></td>
            </tr>
            <tr>
                <td><input type="date" name="date" required></td>
            </tr>
             <tr>
                <td><label>CONTRASEÑA</label></td>
            </tr>
            <tr>
                <td><input type="password" name="text_password" placeholder="Ingresa su contraseña" required></td>
            </tr>
            <tr>
                <td><label>DIRECCION</label></td>
            </tr>
            <tr>
                <td><input type="text" name="text_direccion" placeholder="ingresa tu direccion" required></td>
            </tr>
            <tr>
                <br>
                <td><label for="miCombobox">Elige tu rol:</label>
                    <select id="miCombobox" name="rol" required>
                        <option value="cliente">cliente</option>
                        <option value="proveedor">proveedor</option>
                    </select></td>
            </tr>
            <tr>
                <br>
                <td><label for="miCombobox">Elige tu categoria:</label>
                    <select id="Combobox" name="categoria" required>
                        <option value="Ganadería">Ganaderia</option>
                        <option value="Agricultura">Agricultura</option>
                        <option value="Pesca">Pesca</option>
                        <option value="Mineria">Mineria</option>
                        <option value="Silvicultura">Silvicultura</option>
                        <option value="Apicultura">Apicultura</option>
                    </select></td>
            </tr>
                <td><input type="submit" name="bt_ingresar" value="INGRESAR"></td>
            </tr>
        </table>
    </form>
    <a href="index.php">volver</a>
</body>
</html>
<?php
include("conexion.php");

if (isset($_POST['bt_ingresar'])) {
    $nombre   = $_POST['text_nombre'];
    $usuario  = $_POST['text_username'];
    $identificacion = $_POST['text_identificacion'];
    $telefono = $_POST['num_telefono'];
    $correo   = $_POST['text_correo'];
    $fecha    = $_POST['date'];
    $password = password_hash($_POST['text_password'], PASSWORD_DEFAULT);
    $rol      = $_POST['rol'];
    $categoria= $_POST['categoria'];
    $direccion= $_POST['text_direccion'];

    if ($rol == "cliente") {
        $stmt = $conn->prepare("INSERT INTO cliente 
            (nombres, usuario, identificacion, telefono, correo, fecha_nacimiento, user_password, direccion, rol, categoria) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiissssss", 
            $nombre, $usuario, $identificacion, $telefono, 
            $correo, $fecha, $password, $direccion, $rol, $categoria
        );

    } elseif ($rol == "proveedor") {
        $stmt = $conn->prepare("INSERT INTO proveedores 
            (nombres, usuario, identificacion, telefono, correo, fecha_nacimiento, user_password, direccion, rol, categoria) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiissssss", 
            $nombre, $usuario, $identificacion, $telefono, 
            $correo, $fecha, $password, $direccion, $rol, $categoria
        );
    }

    if ($stmt->execute()) {
        echo "<script>alert('✅ Usuario registrado correctamente'); window.location='login.php';</script>";
    } else {
        echo "❌ Error al registrar: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>




