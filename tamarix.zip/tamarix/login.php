<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
include("conexion.php");

if (isset($_POST['bt_ingresar'])) {
    $usuario   = trim($_POST['text_usuario']);
    $password  = trim($_POST['text_password']);

    // Buscar el usuario tanto en cliente como en proveedor
    $sql = "
        SELECT id_cliente AS id, usuario, user_password, 'cliente' AS rol 
        FROM cliente WHERE usuario=? 
        UNION 
        SELECT id_pro AS id, usuario, user_password, 'proveedor' AS rol 
        FROM proveedores WHERE usuario=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $usuario, $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {

        // ✅ Verificar contraseña con password_verify
        if (password_verify($password, $row['user_password'])) {
            $_SESSION['usuario'] = $row['usuario'];
            $_SESSION['rol'] = $row['rol'];
            $_SESSION['id'] = $row['id'];

            // Redirigir según el rol
            if ($row['rol'] === 'proveedor') {
                header("Location: pag_proveedor.php");
                exit;
            } elseif ($row['rol']=== 'cliente') {
                header("Location: catalogo_cliente.php");
                exit;
            }else {
                header("Location: login.php");
                exit;
            }

        } else {
            echo "<script>alert('❌ Contraseña incorrecta'); window.location='login.php';</script>";
        }
    } else {
        echo "<script>alert('❌ Usuario no encontrado'); window.location='login.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Sesión</title>
</head>
<body>
    <form action="login.php" method="POST">
        <table>
            <tr>
                <td colspan="2" style="color: white; background-color:#1133337c; padding-bottom: 5px; border-radius: 20px;">
                    <label style="color: #b2c5ac;">INICIAR SESIÓN</label>
                </td>
            </tr>
            <tr>
                <td rowspan="6"><img src="logo.png" width="200" height="200" style="border-radius: 50px;"></td>
                <td><label style="color: #3f8043">USUARIO</label></td>
            </tr>
            <tr>
                <td><input type="text" name="text_usuario" placeholder="Ingresar usuario" required></td>
            </tr>
            <tr>
                <td><label style="color: #3f8043">CONTRASEÑA</label></td>
            </tr>
            <tr>
                <td><input type="password" name="text_password" placeholder="Ingresar contraseña" required></td>
            </tr>
            <tr>
                <td><input type="submit" name="bt_ingresar" value="INGRESAR"></td>
            </tr>
            <tr>
                <td>
                    <a href="#">¿Olvidaste tu contraseña?</a><br><br>
                    <a href="user.php">Crear una nueva cuenta</a>
                </td>
            </tr>
        </table>
    </form>
    <a href="index.php">Volver</a>
</body>
</html>
