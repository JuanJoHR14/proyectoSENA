<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include('conexion.php');

// Verificar sesión y rol
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'proveedor') {
    header('Location: login.php');
    exit;
}

$id_pro = intval($_SESSION['id']);
$mensaje = "";

// Agregar producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $categoria = trim($_POST['categoria']);
    $precio = floatval($_POST['precio']);
    $cantidad = intval($_POST['cantidad']);
    $fecha_publicacion = str_replace("T", " ", $_POST['fecha_publicacion']) . ":00";
    $imagen = 'uploads/default.png';

    // Subida de imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $nombreArchivo = basename($_FILES['imagen']['name']);
        $rutaDestino = "uploads/" . uniqid() . "_" . $nombreArchivo;

        if (!file_exists("uploads")) {
            mkdir("uploads", 0777, true);
        }

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            $imagen = $rutaDestino;
        }
    }

    // Insertar producto
    $stmt = $conn->prepare("INSERT INTO productos 
        (nombre, descripcion, categoria, precio, cantidad, imagen, fecha_publicacion, id_pro) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdissi", 
        $nombre, 
        $descripcion, 
        $categoria, 
        $precio, 
        $cantidad, 
        $imagen, 
        $fecha_publicacion, 
        $id_pro
    );

    if ($stmt->execute()) {
        $mensaje = "Producto agregado correctamente.";
    } else {
        $mensaje = "Error al agregar producto: " . $stmt->error;
    }
    $stmt->close();
}

// Eliminar producto
if (isset($_GET['delete'])) {
    $prod_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM productos WHERE id_producto = ? AND id_pro = ?");
    $stmt->bind_param("ii", $prod_id, $id_pro);
    if ($stmt->execute()) {
        $mensaje = "Producto eliminado correctamente.";
    } else {
        $mensaje = "Error al eliminar producto: " . $stmt->error;
    }
    $stmt->close();
}

// Listar productos del proveedor
$stmt = $conn->prepare("SELECT id_producto, nombre, descripcion, precio_unitario, categoria, cantidad, imagen, fecha_publicacion 
                        FROM productos WHERE id_pro = ?");
$stmt->bind_param("i", $id_pro);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Productos</title>
</head>
<body>

<h2>Panel del Proveedor - Productos</h2>

<?php if ($mensaje): ?>
<p><?php echo $mensaje; ?></p>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
    <label>Nombre:</label>
    <input type="text" name="nombre" required><br>

    <label>Descripción:</label>
    <input type="text" name="descripcion" required><br>

    <label>Categoría:</label>
    <input type="text" name="categoria" required><br>

    <label>Precio:</label>
    <input type="number" step="0.01" name="precio" required><br>

    <label>Cantidad:</label>
    <input type="number" name="cantidad" required><br>

    <label>Imagen:</label>
    <input type="file" name="imagen" accept="image/*" required><br>

    <label>Fecha de publicación:</label>
    <input type="datetime-local" name="fecha_publicacion" required><br>

    <input type="submit" name="add_product" value="Agregar producto">
</form>

<h3>Mis productos</h3>
<table border="1" cellpadding="5">
    <tr>
        <th>Imagen</th>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Categoría</th>
        <th>Precio</th>
        <th>Cantidad</th>
        <th>Fecha publicación</th>
        <th>Acción</th>
    </tr>
    
    <?php while ($row = $result->fetch_assoc()): 
    
        //se utiliza el operador de fusion ??'' para asegurar que siempre pase un string//?>

    <tr>
        <td><img src="<?php echo htmlspecialchars($row['imagen'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" width="80" height="80"></td>
        <td><?php echo htmlspecialchars($row['nombre'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($row['descripcion'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($row['categoria'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo number_format($row['precio_unitario'], 2); ?></td>
        <td><?php echo $row['cantidad']; ?></td>
        <td><?php echo $row['fecha_publicacion']; ?></td>
        <td><a href="?delete=<?php echo $row['id_producto']; ?>" onclick="return confirm('¿Eliminar este producto?')">Eliminar</a></td>
    </tr>
    <?php endwhile; ?>
</table>

<p><a href="pag_proveedor.php">Volver</a></p>

</body>
</html>

