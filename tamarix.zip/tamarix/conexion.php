<?php 
$dbhost = "localhost";
$dbuser= "root";
$dbpass = "honey1308";
$dbname = "tamarix";

$conn=mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die("Conexion fallida: " . mysqli_connect_error());
}
?>