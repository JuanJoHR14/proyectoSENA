<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="index.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>YJGrowers</title>
  
</head>
<body>

<!-- <div class="ini">
      <a href="login.php" ">Iniciar sesión</a>
    </div>-->
<link rel="stylesheet" href="index.css">

<header> 
    <div class="h">
        <img src="logo.png" alt="" width="9%">
        <h1 class="a">YJGROWERS</h1> 
        <img src="logo.png" alt="" width="9%">
        <form method="POST">
        <div class="ini">
        <div class="kl ">
        <button class="ab"><a href="login.php" >Iniciar sesión</a></button><br><br>
        <button class="ac"><a href="user.php" >Crear cuenta</a></button>
        </div>
    </div>
    </form>
     
    </div>
</header>


<nav>
    <div>
        <h1 class="b">SOBRE NOSOTROS</h1> 
    </div>

</nav>


<aside> 
    <div class="l">
        <div>
        <ul>
            <li>Te podria interesar:</li>
        </ul>   
        </div>
        <div>
            <a href="contact.php">Contactanos</a>
        </div><br>
        <div>
            <a href="servicios.php">Servicios</a>
        </div><br>
        <div>
            <a href="comentarios.php">Comentarios</a>
        </div><br>
        <div class="l1">
            <img src="nop.png" alt=""  height="250px">
        </div>
    </div>
</aside>


<section>
    <div class="si">
        <div class="no">
            <video class="vi" src="vid.mp4" controls></video>
           
        </div>
        <div class="wno">
            <h4>SOMOS</h4>
            <p>En YJ Growers nos centramos en brindar un aplicativo
                 útil para poder comercializar productos y de otro 
                 modo poder realizar la compra de estos alimentos o
                 productos agrarios de manera más fácil y directa 
                 con su proveedor. Esto para evitar en gran parte 
                 la intervención de terceros, buscamos amenizar 
                 la comercialización de productos agrícolas, 
                 así como garantizar una buena experiencia en 
                 cuanto a comprar y vender.
</p>
        </div>
    </div>
</section>


<article>
    <div class="c">
        <div>
            <h4>MISION</h4>
            <P class="ñ">Nuestra misión como empresa es crear un aplicativo, 
                que facilite la comercialización de productos del campo con 
                los consumidores de la ciudad, esto haciendo más justa la 
                venta y compra de los mismos, facilitando la comercialización 
                de productos agrícolas.</P>

        </div>
        <div class="k">
            <img src="hi.png" alt="" widht="160%" height="190px">
        </div>
        <div>
            <h4>VISION</h4>
            <P class="n">Para el año 2030 esperamos lograr llevar a cabo nuestro 
                sitio web y que empiece a tomar renombre en la ciudad, en el 
                año 2035 queremos lograr ser una de las aplicaciones más famosas
                y mejores en la ciudad en el sector de la comercialización de 
                productos del campo en la ciudad.</P>

        </div>
    </div>

</article>

<footer><a href="">Politica de privacidad</a></footer>
<footer><a href="">Declaracion de cookies</a></footer>
<footer><a href="">Desarrolladores</a></footer>
<footer><a href="">Limitacion de responsabilidad</a></footer>
<body>
<!--    <form method="POST">
        <input style="align-items: center; display: flex; justify-content: center; background-color: rgb(23, 87, 182);float: center; width: 20%; height: 10%;
    border-color: aliceblue; color: rgb(255, 255, 255);" type="submit" value="Cerrar Sesion" name="btncerrar">

    </form>-->
</body>  








</body>
</html>
